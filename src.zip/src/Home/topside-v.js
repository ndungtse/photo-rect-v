
import './Home.css';
import Stories from './stories';
import Mainconts from './mainconts'

function Side() {
  return ( 
      <div className='side'>
          <Stories />
          <Mainconts />
      </div>
  );
}

export default Side;
