
import './Home.css';
import Stories from './stories';
import Mainconts from './mainconts'

function Main() {
  return ( 
      <div className='main'>
          <Stories />
          <Mainconts />
      </div>
  );
}

export default Main;
