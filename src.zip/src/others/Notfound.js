import React from 'react'

const Notfound = () => {
  return (
    <div className="w-full flex flex-col">
        <h1 className='text-[10em] text-center'>404</h1>
        <h1 className='text-[2em] text-center'>Page Not Found</h1>
    </div>
  )
}

export default Notfound